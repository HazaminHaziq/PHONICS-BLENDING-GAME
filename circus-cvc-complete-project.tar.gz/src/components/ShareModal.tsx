import React, { useState, useEffect } from 'react';
import { X, Copy, Check, QrCode, Maximize2, Minimize2, Download, ExternalLink, ShieldCheck, Users } from 'lucide-react';
import QRCode from 'qrcode';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [isProjectorMode, setIsProjectorMode] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  // Determine the guaranteed public access link
  const getPublicShareUrl = (): string => {
    const defaultPublicUrl = 'https://ais-pre-5wzjgoctv3uwttj5accwut-759838092087.asia-northeast1.run.app';
    if (typeof window !== 'undefined') {
      const current = window.location.href;
      // Convert development URL to public shareable preview URL
      if (current.includes('-dev-')) {
        return current.replace('-dev-', '-pre-');
      }
      if (current.includes('localhost') || current.includes('127.0.0.1')) {
        return defaultPublicUrl;
      }
      return current;
    }
    return defaultPublicUrl;
  };

  const publicUrl = getPublicShareUrl();

  // Generate high-resolution QR code
  useEffect(() => {
    if (isOpen) {
      QRCode.toDataURL(publicUrl, {
        width: 600,
        margin: 2,
        color: {
          dark: '#1e1b4b',
          light: '#ffffff'
        },
        errorCorrectionLevel: 'H'
      })
        .then(url => setQrDataUrl(url))
        .catch(err => console.error('Failed to generate QR code', err));
    }
  }, [isOpen, publicUrl]);

  if (!isOpen) return null;

  const handleCopyLink = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(publicUrl);
      } else {
        // Fallback for older browsers or restricted iframe policies
        const textArea = document.createElement('textarea');
        textArea.value = publicUrl;
        textArea.style.position = 'fixed';
        textArea.style.left = '-9999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleDownloadQR = () => {
    if (!qrDataUrl) return;
    const link = document.createElement('a');
    link.href = qrDataUrl;
    link.download = 'circus-phonics-year1-qrcode.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div
        className={`bg-white rounded-3xl border-4 border-amber-400 shadow-2xl relative transition-all duration-200 flex flex-col ${
          isProjectorMode
            ? 'max-w-3xl w-full p-6 sm:p-8'
            : 'max-w-lg w-full p-5 sm:p-7'
        }`}
      >
        {/* Top Controls */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-100 mb-4">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-100 text-amber-800 border border-amber-300">
              <QrCode className="w-5 h-5" />
            </span>
            <div>
              <h2 className="font-fun text-xl sm:text-2xl font-black text-slate-900 leading-tight">
                Share With Participants
              </h2>
              <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Public Link · Anyone with the link can join</span>
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setIsProjectorMode(!isProjectorMode)}
              className="px-2.5 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 text-xs font-fun font-bold flex items-center gap-1 cursor-pointer transition-colors"
              title={isProjectorMode ? 'Exit Smartboard Mode' : 'Smartboard Projection Mode'}
            >
              {isProjectorMode ? (
                <>
                  <Minimize2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Normal View</span>
                </>
              ) : (
                <>
                  <Maximize2 className="w-3.5 h-3.5 text-red-600" />
                  <span className="hidden sm:inline">Projector Mode</span>
                </>
              )}
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-xl hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* QR Code Presentation */}
        <div className="flex flex-col items-center text-center my-1">
          <div
            className={`bg-gradient-to-b from-amber-100 via-orange-50 to-amber-100 p-4 rounded-3xl border-3 border-amber-300 shadow-inner flex flex-col items-center justify-center transition-all ${
              isProjectorMode ? 'p-6 sm:p-8' : 'p-3'
            }`}
          >
            {qrDataUrl ? (
              <img
                src={qrDataUrl}
                alt="Scan to open Circus Phonics Game"
                className={`rounded-2xl shadow-md border-2 border-white transition-all ${
                  isProjectorMode
                    ? 'w-64 h-64 sm:w-80 sm:h-80'
                    : 'w-48 h-48 sm:w-56 sm:h-56'
                }`}
              />
            ) : (
              <div className="w-48 h-48 flex items-center justify-center bg-white rounded-2xl animate-pulse text-xs text-slate-400 font-bold">
                Generating QR Code...
              </div>
            )}

            <div className="mt-3 flex items-center gap-2">
              <span className="font-fun text-xs sm:text-sm font-bold text-amber-950">
                📷 Scan with camera on iPad, Tablet, or Phone
              </span>
            </div>
          </div>
        </div>

        {/* Public URL Box & Copy Button */}
        <div className="mt-4 bg-slate-50 border-2 border-amber-200 rounded-2xl p-3 flex flex-col sm:flex-row items-center gap-2">
          <div className="flex-1 w-full overflow-hidden">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Direct Public Link:
            </span>
            <input
              type="text"
              readOnly
              value={publicUrl}
              onFocus={(e) => e.target.select()}
              className="w-full text-xs font-mono font-semibold text-slate-800 bg-transparent truncate outline-none select-all"
            />
          </div>

          <div className="flex items-center gap-1.5 w-full sm:w-auto shrink-0">
            <button
              onClick={handleCopyLink}
              className={`flex-1 sm:flex-initial px-4 py-2 rounded-xl font-fun text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer ${
                copied
                  ? 'bg-emerald-600 text-white'
                  : 'bg-red-600 hover:bg-red-700 active:scale-95 text-white'
              }`}
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-white" />
                  <span>Copied! ✓</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copy Link</span>
                </>
              )}
            </button>

            <button
              onClick={handleDownloadQR}
              className="p-2 rounded-xl bg-white hover:bg-amber-100 text-amber-900 border border-amber-300 transition-colors cursor-pointer"
              title="Download QR code image to print for classroom"
            >
              <Download className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Classroom Access Guarantees */}
        <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-2 text-left">
          <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-center">
            <span className="text-base block mb-0.5">🔓</span>
            <span className="font-fun text-xs font-bold text-amber-950 block">No Login Required</span>
            <span className="text-[10px] text-slate-600">Pupils enter immediately with one tap.</span>
          </div>

          <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-center">
            <span className="text-base block mb-0.5">🎤</span>
            <span className="font-fun text-xs font-bold text-emerald-950 block">No Mic Blockers</span>
            <span className="text-[10px] text-slate-600">Plays pure British audio safely in any browser.</span>
          </div>

          <div className="p-2.5 rounded-xl bg-purple-50 border border-purple-200 text-center">
            <span className="text-base block mb-0.5">💻</span>
            <span className="font-fun text-xs font-bold text-purple-950 block">All Devices</span>
            <span className="text-[10px] text-slate-600">Chromebooks, smartboards, iOS & Android.</span>
          </div>
        </div>

        {/* Footer Note */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span className="font-medium text-[11px]">
            Tip: You can project this on your classroom smartboard during phonics lessons.
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-fun font-bold cursor-pointer transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
